<article class="col-xs-12 maincontent">

<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
    <div class="panel panel-info">
        <div class="panel-heading" > <h4 class="thin text-center">Quick Links</h4></div>
            <div class="panel-body">


            </div>
    </div>
</div>
</article>