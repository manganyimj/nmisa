<?php
	session_start();
	
	$_SESSION["message"] = " ";
	if(isset($_POST["register"]))
	{
		
		
		$gender = $_POST['gender'];
		$title = $_POST['title'];
		$lastname = $_POST['lastname'];
		$name = $_POST['name'];
		$type = $_POST['type'];
		$idno = $_POST['idno'];
		$dob = $_POST['dob'];
		$cellNO = $_POST['cellNO'];
		$email = $_POST['email'];
		$password = $_POST['password'];
		$province = $_POST['province'];
		$physicalAddress = $_POST['physicalAddress'];
		$incomeType = $_POST['incomeType'];
		$advertisement = $_POST['advertisement'];
			

		$_SESSION["message"] = "User successfully registered";
		
		header("Location:index.php");
				
				/*require_once('dbConnect.php');
						
				$sqlEmail = "SELECT * FROM tblMembers WHERE email = '$email'";
						
				$checkEmail = mysqli_fetch_array(mysqli_query($con,$sqlEmail));
				
				$sqlPhoneNO = "SELECT * FROM tblMembers WHERE cellNO = '$cellNO'";
						
				$checkPhoneNO = mysqli_fetch_array(mysqli_query($con,$sqlPhoneNO));
				
				$sqlIdNO = "SELECT * FROM tblMembers WHERE idno = '$idno'";
						
				$checkIdNO = mysqli_fetch_array(mysqli_query($con,$sqlIdNO));
				
				if(isset($checkEmail))
				{
					$_SESSION["message"]= "User with the same email already exist";
					header("Location:index.php");
				}
				else if(isset($checkIdNO))
				{
					$_SESSION["message"]= "User with the same id number already exist";
					header("Location:index.php");
				}
				else if($checkPhoneNO)
				{
					$_SESSION["message"] = "User with the same phone number already exist";
					header("Location:index.php");
				}
				else
				{
					$sql = "INSERT INTO tblMembers(gender,title,lastname,name,type,idno,dob,cellNO,email,password, province,physicalAddress,incomeType,advertisement) VALUES('$gender','$title','$lastname','$name','$type','$idno','$cellNO','$email','$password','$province','$physicalAddress','$incomeType','$advertisement')";
					
							
					if(mysqli_query($con,$sql))
					{
						$to      = $email;
						$subject = 'SUCCESSFULLY REGISTERED';
						$message = "Dear " .$name ." " .$lastname . "\n\n\nWelcome to Esibayeni holding here is your Username: " .$email . " and password is : " . $password . "\n\n Kind Regards \n\n Admin";
						$headers = 'From: no_reply@esibayeni.co.za' . "\r\n" .
						'Reply-To: no_reply@esibayeni.co.za' . "\r\n" .
						'X-Mailer: PHP/' . phpversion();

						mail($to, $subject, $message, $headers);
						
						$_SESSION["message"] = "User successfully registered";
						header("Location:index.php");
							
					}
					else
					{
						$_SESSION["message"] = "User unsuccessfully registered";
						header("Location:index.php");
					}
				}
				
				mysqli_close($con);*/
	
		
				
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Index | MDT</title>
	
	<!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->
<body>
	<header id="header">
       

        <nav class="navbar navbar-inverse" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <!-- <a class="navbar-brand" href="index.html"><img src="images/logo.png" alt="logo"></a> -->
					<a class="navbar-brand" href="index.html"><img src="images/logo.png"  class = "img-responsive img-thumbnail" alt="logo"></a>
					<!-- <a class="navbar-brand" style="box-shadow: 1px red;">MD Technologies</a> -->
                </div>
				
                <div class="collapse navbar-collapse navbar-right ">
                    <ul class="nav navbar-nav ">
					    <li class="hidden">
                           <a href="#page-top"></a>
                        </li>
                        <li><a class="page-scroll" href="index.html">Home</a></li>
						<li><a class="page-scroll" href="services.php">Questiner</a></li>
                        <li><a class="page-scroll" href="about-us.html">View Cart</a></li>
						<li><a class="page-scroll" href="ourteam.html">My bill</a></li>
						<li><a class="page-scroll" href="contact-us.php">Login</a></li>
						                   
                    </ul>
                </div>
            </div>
        </nav>
		
    </header>


	<!-- BLOG -->
<section id="register">
		<div class="container">
			<div class="row">
				<div class="col-md-10 col-md-offset-1">
					<div class="panel panel-primary">
					<div class="panel-heading"><h4 class="thin text-center">Institution Information </h4></div>
						<div class="panel-body">
							<div class="col-sm-10 col-sm-offset-1">
								<form action="php/register.php" class="contact-form" name="contact-form" method="post">
									<div class="row">
					<div class="col-sm-8 col-sm-offset-2">
                        <div class="form-group">
						    <label>Who does your institution currently use PT scheme provider:</label>
						    <select class ="form-control" name=product id="product" type ="text" required >
								<option>sssss</option>
								<option>sssss</option>
								<option>sssss</option>
								<option>sssss</option> 
							</select>
                        </div>
                        <div class="form-group">
                            <label>Where does your institution currently source reference materials from:</label>
                            <select class ="form-control" name=product id="product" type ="text" required >
								<option>sssss</option>
								<option>sssss</option>
								<option>sssss</option>
								<option>sssss</option> 
							</select>
                        </div>
                        <div class="form-group">
                            <label>Additional comments/details on measurand matrix and RM type required for your application:</label>
                            <textarea type="number" class="form-control"> </textarea>
                        </div>
						<div class="form-group">
                            <label>Comments</label>
                            <textarea type="number" class="form-control"> </textarea>
                        </div>
						<center><a href="institution.php" class="btn btn-primary">Save and Continue</a></center>
						</div>
						<div class="col-sm-5 col-sm-offset-1">
                   
						
						</div>
                        					
                    </div>
					   
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	<!-- /BLOG -->

	<footer id="footer" class="midnight-blue">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    &copy; 2015 <a href="#" >NMISA</a>. All Rights Reserved.
                </div>
				
				<div class="col-sm-6">
                    <ul class="pull-right">
                        <li><a href=""><i class="fa fa-twitter"></i></a>
                        </li>
                        <li><a href="https://www.facebook.com/MDynamic-Technologies-531421617061250/?fref=ts"><i class="fa fa-facebook"></i></a>
                        </li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a>
                        </li>
                    </ul>
                </div>
				
            </div>
        </div>
    </footer><!--/#footer-->
	<!-- Scroll-up -->
	<div class="scroll-up">
		<ul><li><a href="#header"><i class="fa fa-angle-up"></i></a></li></ul>
	</div>
	
	<!-- JS -->
	<script type="text/javascript" src="js/jquery.min.js"></script><!-- jQuery -->
	<script type="text/javascript" src="js/bootstrap.min.js"></script><!-- Bootstrap -->
	<script type="text/javascript" src="js/jquery.parallax.js"></script><!-- Parallax -->
	<script type="text/javascript" src="js/smoothscroll.js"></script><!-- Smooth Scroll -->
	<script type="text/javascript" src="js/masonry.pkgd.min.js"></script><!-- masonry -->
	<script type="text/javascript" src="js/jquery.fitvids.js"></script><!-- fitvids -->
	<script type="text/javascript" src="js/owl.carousel.min.js"></script><!-- Owl-Carousel -->
	<script type="text/javascript" src="js/jquery.counterup.min.js"></script><!-- CounterUp -->
	<script type="text/javascript" src="js/waypoints.min.js"></script><!-- CounterUp -->
	<script type="text/javascript" src="js/jquery.isotope.min.js"></script><!-- isotope -->
	<script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script><!-- magnific-popup -->
	<script type="text/javascript" src="js/scripts.js"></script><!-- Scripts -->


</body>
</html>