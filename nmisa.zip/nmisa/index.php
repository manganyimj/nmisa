<?php

session_start();

if(isset($_POST["login"]))
{
         echo "John";
		/*$email = $_POST['email'];
		$password = $_POST['password'];
	
		require_once('dbConnect.php');
		
	        $sql = "SELECT * FROM tblregister WHERE email ='$email' && password='$password'";
			
		$check = mysqli_fetch_array(mysqli_query($con,$sql));
		$result = array();
		if(isset($check))
		{
			
			$result = $con->query($sql);
			if ($result->num_rows > 0)
			{
				
                            while($row = $result->fetch_assoc()) 
                            {
                                $_SESSION["memberId"] = $row["memberid"];
                                $_SESSION["name"] = $row["name"];
                                $_SESSION["surname"] = $row["surname"];
                                $_SESSION["phone"] = $row["phone"];
                                $_SESSION["email"] = $row["email"];
                                $_SESSION["password"] = $row["password"];
                                $_SESSION["usertype"] = $row["usertype"];
                                $_SESSION["imageP"] = $row["image"];
                                $_SESSION["usernameOption"] = $row["usernameOption"];
                                $_SESSION["usertype"] = $row["usertype"];
                                $_SESSION["gender"] = $row["gender"];
                                $id = $row["memberid"];

                                $role=$row["usertype"];;
                                if($role=='Admin')
                                {
                                   header('location:adminProfile.php');
                                    

                                }
                                else
                                {

                                    header('location:profile.php');

                                }
                            }
                            
                        }
                        $sql = "SELECT * FROM additionalinfo WHERE  fkmenberid='$id'";
			
                        $check = mysqli_fetch_array(mysqli_query($con,$sql));
                        $result = array();
                        if(isset($check))
                        {
                            $result = $con->query($sql);
			    if ($result->num_rows > 0)
			    {
				
                                 while($row = $result->fetch_assoc()) 
                                 {
                                     $_SESSION["place"] = $row["place"];
                                     $_SESSION["primSchool"] = $row["primSchool"];
                                     $_SESSION["highSchool"] = $row["highSchool"];
                                     $_SESSION["yearMatricPassed"] = $row["yearMatricPassed"];
                                     $_SESSION["Varsity"] = $row["Varsity"];
                                     
                                     
                                 }
                            }
                        }
                        else 
                        {
                                     $_SESSION["place"] = ' ';
                                     $_SESSION["primSchool"] = ' ';
                                     $_SESSION["highSchool"] = ' ';
                                     $_SESSION["yearMatricPassed"] = ' ';
                                     $_SESSION["Varsity"] = ' ';         
                        }
			
								
		}
		else
		{
			$_SESSION["logMssg"]="please provide valid creditials";
		}
	
		mysqli_close($con); */
	
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="utf-8">
	<link rel="shortcut icon" href="images/logo.jpg">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Index | MDT</title>
	
	<!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body class="homepage">

</head><!--/head-->
           
		   <header id="header">
       

        <nav class="navbar navbar-inverse" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <!-- <a class="navbar-brand" href="index.html"><img src="images/logo.png" alt="logo"></a> -->
					<a class="navbar-brand" href="index.html"><img src="images/logo.png"  class = "img-responsive img-thumbnail" alt="logo"></a>
					<!-- <a class="navbar-brand" style="box-shadow: 1px red;">MD Technologies</a> -->
                </div>
				
                <div class="collapse navbar-collapse navbar-right ">
                    <ul class="nav navbar-nav ">
					    <li class="hidden">
                           <a href="#page-top"></a>
                        </li>
                        <li><a class="page-scroll" href="index.html">Home</a></li>
						<li><a class="page-scroll" href="services.php">Questiner</a></li>
                        <li><a class="page-scroll" href="about-us.html">View Cart</a></li>
						<li><a class="page-scroll" href="ourteam.html">My bill</a></li>
						<li><a class="page-scroll" href="contact-us.php">Login</a></li>
						                   
                    </ul>
                </div>
            </div>
        </nav>
		
    </header></br> </br> 

	<div class="row">
		<div class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
			<div class="login-panel panel panel-default">
				<div class="panel-heading">Log in</div>
				<div class="panel-body">
					<form role="form" action="<?php echo $_SERVER['PHP_SELF'] ;?>" method="POST">
						<fieldset>
							<div class="form-group">
								<input class="form-control" placeholder="E-mail" name="email" type="email" autofocus="">
							</div>
							<div class="form-group">
								<input class="form-control" placeholder="Password" name="password" type="password" value="">
							</div>
							<div class="checkbox">
								<label>
									<input name="remember" type="checkbox" value="Remember Me">Remember Me
								</label>
							</div>
							<a href="institution.php" class="btn btn-primary">Login</a> <a href="register.php" class="btn btn-primary">Sign up</a>
						</fieldset>
					</form>
				</div>
			</div>
		</div><!-- /.col-->
	</div><!-- /.row -->	
	</br> 
	

    <footer id="footer" class="midnight-blue">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    &copy; 2015 <a href="#" >MDynamic Tech</a>. All Rights Reserved.
                </div>
				
				<div class="col-sm-6">
                    <ul class="pull-right">
                        <li><a href=""><i class="fa fa-twitter"></i></a>
                        </li>
                        <li><a href="https://www.facebook.com/MDynamic-Technologies-531421617061250/?fref=ts"><i class="fa fa-facebook"></i></a>
                        </li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a>
                        </li>
                    </ul>
                </div>
				
            </div>
        </div>
    </footer><!--/#footer-->
	
		<!-- JS -->
	<script type="text/javascript" src="js/jquery.min.js"></script><!-- jQuery -->
	<script type="text/javascript" src="js/bootstrap.min.js"></script><!-- Bootstrap -->
	<script type="text/javascript" src="js/jquery.parallax.js"></script><!-- Parallax -->
	<script type="text/javascript" src="js/smoothscroll.js"></script><!-- Smooth Scroll -->
	<script type="text/javascript" src="js/masonry.pkgd.min.js"></script><!-- masonry -->
	<script type="text/javascript" src="js/jquery.fitvids.js"></script><!-- fitvids -->
	<script type="text/javascript" src="js/owl.carousel.min.js"></script><!-- Owl-Carousel -->
	<script type="text/javascript" src="js/jquery.counterup.min.js"></script><!-- CounterUp -->
	<script type="text/javascript" src="js/waypoints.min.js"></script><!-- CounterUp -->
	<script type="text/javascript" src="js/jquery.isotope.min.js"></script><!-- isotope -->
	<script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script><!-- magnific-popup -->
	<script type="text/javascript" src="js/scripts.js"></script><!-- Scripts -->

    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/wow.min.js"></script>
</body>
</html>