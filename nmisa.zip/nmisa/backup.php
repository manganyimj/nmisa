<?php
session_start();
require_once("dbcontroller.php");
$db_handle = new DBController();

?>
<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Index | MDT</title>
	
	<!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->
           
		   <header id="header">
       

        <nav class="navbar navbar-inverse" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <!-- <a class="navbar-brand" href="index.html"><img src="images/logo.png" alt="logo"></a> -->
					<a class="navbar-brand" href="index.html"><img src="images/logo.png"  class = "img-responsive img-thumbnail" alt="logo"></a>
					<!-- <a class="navbar-brand" style="box-shadow: 1px red;">MD Technologies</a> -->
                </div>
				
                <div class="collapse navbar-collapse navbar-right ">
                    <ul class="nav navbar-nav ">
					    <li class="hidden">
                           <a href="#page-top"></a>
                        </li>
                        <li><a class="page-scroll" href="index.html">Home</a></li>
						<li><a class="page-scroll" href="services.php">Questiner</a></li>
                        <li><a class="page-scroll" href="about-us.html">View Cart</a></li>
						<li><a class="page-scroll" href="ourteam.html">My bill</a></li>
						<li><a class="page-scroll" href="contact-us.php">Login</a></li>
						                   
                    </ul>
                </div>
            </div>
        </nav>
		
    </header>
	</br></br>
<body class="homepage">


	  
	  <table width="100%" border=10>
	   
	   <tr style="color:black"><center><b>RM TYPE  </br>In-house Quality Control RM = A   </br>Proficiency Testing Scheme = B  </br>Certified Reference Material = C</b></center></tr>
       <tr>
	       <td style="color:black"> <center><b>Product categories</b></center> </td>
		   <td style="color:black"> <center><b>Measurand  </b></center></td> 
		   <td style="color:black"> <center><b>RM TYPE  </b></center></td>
	       <td style="color:black"> <center><b>Add to Cart</b></center></td>
	   </tr>
	   
	   
	   
        <?php
					        include './PHP/Product.php';
						
        
						$result = $db_handle->runQuery("SELECT * FROM tblproductcat ORDER BY id ASC");
                        
						foreach($result as $key=>$value){
					          $Product =array($result[$key]["id"],$result[$key]["productname"]);
						}
						
                                                $starter = 0;
                                                $ender = 0;
						
						if (!empty($Product)){
                                                    
                                                    $counter = $starter;
                                                    
                                                    for($x = 0; $x < sizeof($Product); $x++){
                                                       
                                                        echo '<p style="color:black">',$Product[$x],'</p>';  
                                                    }
						 
						   /*foreach($result as $key=>$value){
							 							 
						    echo '<tr>';
							echo '<div class="product">';
							echo '<div class="info">';
							
							echo '<td>'; 
							echo '<p style="color:black">',$result[$key]["productname"],'</p>';  
							echo '</td>';
							
							echo '<td>';
							    
							    echo '<select class ="form-control" name="serviceType" id="serviceType" type ="text" required >';
								     echo '<option>';
									    echo '---select---';
									 echo '</option>';
							      foreach($result as $key=>$value){
									 
									 echo '<option>',$result[$key]["productname"], '</option>'; 
                                     									 
								  }
							echo '</td>';
							
						    echo '<td>';
								   echo '<input type=checkbox style=color:green  name=id  value="A" >A';
								   echo '<input type=checkbox style=color:green  name=id  value="B" >B';
								   echo '<input type=checkbox style=color:green  name=id  value="C" >C'; 
						    echo '</td>';
							
							echo '<td>';
								echo '  <center>';
									echo '    <button type="submit" name="submit" class="btn btn-primary btn-lg" required="required">';
										echo '	   Add to cart';
									echo '	</button>';
								echo '  </center>';
							echo '</td>';
								
							
							echo '</div>';
							echo '</div>';
							echo '</tr>';

						   }*/
						
						}
                                                else{
                                                    echo "out side";
                                                }

						$result = array();
						$count =0;
					?>
	   
	   
      </table>
	   
	  <!-- Pagination -->
        <div class="row text-center">
            <div class="col-lg-12">
                <ul class="pagination">
                    <li>
                        <a href="nmisaform2.html">&laquo;</a>
                    </li>
                    <li class="active">
                        <a href="nmisaform2.html">1</a>
                    </li>
                    <li>
                        <a href="nmisaform2.html">2</a>
                    </li>
                    <li>
                        <a href="nmisaform2.html">3</a>
                    </li>
                    <li>
                        <a href="nmisaform2.html">4</a>
                    </li>
                    <li>
                        <a href="nmisaform2.html">5</a>
                    </li>
                    <li>
                        <a href="nmisaform2.html">&raquo;</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- /.row -->
        <!--<center><button type="submit" name="submit" class="btn btn-primary btn-lg" required="required">View Your Cart</button></center>
        <center><button type="submit" name="submit" class="btn btn-primary btn-lg" required="required">Submit</button></center> -->
		</br>
    <footer id="footer" class="midnight-blue">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    &copy; 2015 <a href="#" >NMISA</a>. All Rights Reserved.
                </div>
				
				<div class="col-sm-6">
                    <ul class="pull-right">
                        <li><a href=""><i class="fa fa-twitter"></i></a>
                        </li>
                        <li><a href="https://www.facebook.com/MDynamic-Technologies-531421617061250/?fref=ts"><i class="fa fa-facebook"></i></a>
                        </li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a>
                        </li>
                    </ul>
                </div>
				
            </div>
        </div>
    </footer><!--/#footer-->
	
		<!-- JS -->
	<script type="text/javascript" src="js/jquery.min.js"></script><!-- jQuery -->
	<script type="text/javascript" src="js/bootstrap.min.js"></script><!-- Bootstrap -->
	<script type="text/javascript" src="js/jquery.parallax.js"></script><!-- Parallax -->
	<script type="text/javascript" src="js/smoothscroll.js"></script><!-- Smooth Scroll -->
	<script type="text/javascript" src="js/masonry.pkgd.min.js"></script><!-- masonry -->
	<script type="text/javascript" src="js/jquery.fitvids.js"></script><!-- fitvids -->
	<script type="text/javascript" src="js/owl.carousel.min.js"></script><!-- Owl-Carousel -->
	<script type="text/javascript" src="js/jquery.counterup.min.js"></script><!-- CounterUp -->
	<script type="text/javascript" src="js/waypoints.min.js"></script><!-- CounterUp -->
	<script type="text/javascript" src="js/jquery.isotope.min.js"></script><!-- isotope -->
	<script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script><!-- magnific-popup -->
	<script type="text/javascript" src="js/scripts.js"></script><!-- Scripts -->

    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/wow.min.js"></script>
</body>
</html>
