<?php
session_start();
require_once("dbcontroller.php");
$db_handle = new DBController();

if(isset($_POST["add"]))
{
	
	        $product = $_POST["product"];
			$measurend = $_POST["measurendname"];
			
			if(!empty($_POST["A"]))
            {
				$A = $_POST["A"];
			}
			else
		    {
				$A = null;
			}
			if(!empty($_POST["B"]))
            {
				$B = $_POST["B"];
			}
			else
		    {
				$B = null;
			}
			if(!empty($_POST["C"]))
            {
				$C = $_POST["C"];
			}
			else
		    {
				$C = null;
			}
			
			$cartid = 1;
			
			$Order = array($product,$measurend,$A,$B,$C);
				
			$Orders = array($Order[$cartid]=>array('product'=>$Order[0],'measurend'=>$Order[1],'A'=>$Order[2],'B'=>$Order[3],'C'=>$Order[4]));
				
			if(!empty($_SESSION["cart_item"])) {
					$_SESSION["cart_item"] = array_merge($_SESSION["cart_item"],$Orders);
			} else {
				$_SESSION["cart_item"] = $Orders;
			}
							
			

}
else if(isset($_POST["remove"]))
{
	    if(!empty($_SESSION["cart_item"])) {
			unset($_SESSION["cart_item"]);
		}
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Index | MDT</title>
	
	<!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
	
	<style>
	
	input[type="checkbox"]{
  width: 18px; /*Desired width*/
  height: 18px; /*Desired height*/
 
}
	
	</style>
	
	
	
</head><!--/head-->
           
 <header id="header">
       

        <nav class="navbar navbar-inverse" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <!-- <a class="navbar-brand" href="index.html"><img src="images/logo.png" alt="logo"></a> -->
					<a class="navbar-brand" href="index.html"><img src="images/logo.png"  class = "img-responsive img-thumbnail" alt="logo"></a>
					<!-- <a class="navbar-brand" style="box-shadow: 1px red;">MD Technologies</a> -->
                </div>
				
                <div class="collapse navbar-collapse navbar-right ">
                    <ul class="nav navbar-nav ">
					    <li class="hidden">
                           <a href="#page-top"></a>
                        </li>
                        <li><a class="page-scroll" href="index.html">Home</a></li>
						<li><a class="page-scroll" href="services.php">Questiner</a></li>
                        <li><a class="page-scroll" href="about-us.html">View Cart</a></li>
						<li><a class="page-scroll" href="ourteam.html">My bill</a></li>
						<li><a class="page-scroll" href="contact-us.php">Login</a></li>
						                   
                    </ul>
                </div>
            </div>
        </nav>
		
    </header>
	</br></br>
<body class="homepage">


	 <form id="contact-form" action="<?php echo $_SERVER['PHP_SELF'] ;?>" method="POST"> 
	  <table width="100%" border=10>
	   
	   <tr style="color:black"><center><b>RM TYPE  </br>In-house Quality Control RM = A   </br>Proficiency Testing Scheme = B  </br>Certified Reference Material = C</b></center></tr>
       <tr>
	       <td style="color:black"> <center><b>Product categories</b></center> </td>
		   <td style="color:black"> <center><b>Measurand  </b></center></td> 
		   <td style="color:black"> <center><b>Frequency with which you require the use of these reference material </b></center></td> 
		   <td style="color:black"> <center><b>Frequency with which you participate in these PT Scheme  </b></center></td> 
		   <td style="color:black" colspan="3"> <center><b>RM TYPE  </b></center></td>
	       <td style="color:black"> <center><b></b></center></td>
	   </tr>
	   
	   
	   
        <?php
						
						
						$allProducts = $db_handle->runQuery("SELECT * FROM tblproductcat ORDER BY id ASC");
                        
						$allMeasurand = $db_handle->runQuery("SELECT * FROM tblmeasurand ORDER BY id ASC");
						
						
						
						
						if (!empty($allProducts)){
							 							 
								echo '<tr>';
								echo '<div class="product">';
								echo '<div class="info">';
								
								
								
								echo '<td>';
									echo '<select class ="form-control" name=product id="product" type ="text" required >';
										 echo '<option>';
											echo '---select---';
										 echo '</option>';
									  foreach($allProducts as $key=>$value){
										 
										 echo '<option>',$allProducts[$key]["productname"], '</option>';									 
									  }
								echo '</td>';
								
								echo '<td>';
									
									echo '<select class ="form-control" name="measurendname" id="measurendname" type ="text" required >';
										 echo '<option>';
											echo '---select---';
										 echo '</option>';
									  foreach($allMeasurand as $key=>$value){
										 
										 echo '<option>',$allMeasurand[$key]["measurendname"], '</option>'; 
																			 
									  }
								echo '</td>';
								
								echo '<td>';
									
									echo '<select class ="form-control" name="measurendname" id="measurendname" type ="text" required >';
									     echo '<option>';
											echo '---select---';
										 echo '</option>';
										 
										 echo '<option>';
											echo 'weekly ';
										 echo '</option>';
										 
										 echo '<option>';
											echo 'monthly ';
										 echo '</option>';
										 
										 echo '<option>';
											echo 'quartely';
										 echo '</option>';
										 
										 echo '<option>';
											echo 'annually';
										 echo '</option>';
								echo '</td>';
								
								echo '<td>';
									
									echo '<select class ="form-control" name="measurendname" id="measurendname" type ="text" required >';
									     echo '<option>';
											echo '---select---';
										 echo '</option>';
										 
										 echo '<option>';
											echo 'weekly ';
										 echo '</option>';
										 
										 echo '<option>';
											echo 'monthly ';
										 echo '</option>';
										 
										 echo '<option>';
											echo 'quartely';
										 echo '</option>';
										 
										 echo '<option>';
											echo 'annually';
										 echo '</option>';
								echo '</td>';
								
								echo '<td>';
									   echo '<input type=checkbox style=color:green  name=A  value="A" >A';
								echo '</td>';	   
								echo '<td>';
									   echo '<input type=checkbox style=color:green  name=B  value="B" >B';
								echo '</td>';
								echo '<td>';
									   echo '<input type=checkbox style=color:green  name=C  value="C" >C'; 
								echo '</td>';
								
								echo '<td>';
									echo '  <center>';
										echo '    <button type="submit" name="add" value="add" class="btn btn-primary btn-lg" required="required">';
											echo '	   Add';
										echo '	</button>';
		
									echo '  </center>';
								echo '</td>';
								
								
									
								
								echo '</div>';
								echo '</div>';
								echo '</tr>';
						
						}
					?>
	   
	   
      </table>
	
     <table width="100%" border=10>
	   
	   
       <tr>
	       <td style="color:black"> <center><b>Product categories</b></center> </td>
		   <td style="color:black"> <center><b>Measurand  </b></center></td>
           <td style="color:black"> <center><b>Frequency with which you require the use of these reference material </b></center></td> 
		   <td style="color:black"> <center><b>Frequency with which you participate in these PT Scheme  </b></center></td> 		   
		   <td style="color:black"> <center><b>RM TYPE  </b></center></td>
	       <td style="color:black"> <center><b>Remove</b></center></td>
	   </tr>
	   
	   
	   
        <?php
						
						
						/* $allProducts = $db_handle->runQuery("SELECT * FROM tblproductcat ORDER BY id ASC");
                        
						$allMeasurand = $db_handle->runQuery("SELECT * FROM tblmeasurand ORDER BY id ASC");
						
						
						
						
						if (!empty($allProducts)){
							 							 
								echo '<tr>';
								echo '<div class="product">';
								echo '<div class="info">';
								
								
								
								echo '<td>';
									echo '<select class ="form-control" name=product id="product" type ="text" required >';
										 echo '<option>';
											echo '---select---';
										 echo '</option>';
									  foreach($allProducts as $key=>$value){
										 
										 echo '<option>',$allProducts[$key]["productname"], '</option>';									 
									  }
								echo '</td>';
								
								echo '<td>';
									
									echo '<select class ="form-control" name="measurendname" id="measurendname" type ="text" required >';
										 echo '<option>';
											echo '---select---';
										 echo '</option>';
									  foreach($allMeasurand as $key=>$value){
										 
										 echo '<option>',$allMeasurand[$key]["measurendname"], '</option>'; 
																			 
									  }
								echo '</td>';
								
								echo '<td>';
									   echo '<input type=checkbox style=color:green  name=A  value="A" >A';
									   echo '<input type=checkbox style=color:green  name=B  value="B" >B';
									   echo '<input type=checkbox style=color:green  name=C  value="C" >C'; 
								echo '</td>';
								
								echo '<td>';
									echo '  <center>';
										echo '    <button type="submit" name="add" value="add" class="btn btn-primary btn-lg" required="required">';
											echo '	   Add to cart';
										echo '	</button>';
										echo '    <button type="submit" name="remove" value="remove" class="btn btn-primary btn-lg" required="required">';
											echo '	   Remove';
										echo '	</button>';
									echo '  </center>';
								echo '</td>';
								
								
									
								
								echo '</div>';
								echo '</div>';
								echo '</tr>';
						
						} */
						if(!empty($_SESSION["cart_item"]))
						{
							foreach ($_SESSION["cart_item"] as $item){
							   
							   echo '<tr>';
							   echo '<div class="product">';
							   echo '<div class="info">';
							   
									echo '<td>';
									   echo $item["product"];
									echo '</td>';	
								   
									echo '<td>';
									   echo $item["measurend"];
									echo '</td>';

									echo '<td>';
									   echo $item["A"]; echo $item["B"]; echo $item["C"];
									echo '</td>';
			
									echo '<td>';
									   echo '    <button type="submit" name="remove" value="remove" class="btn btn-primary btn-lg" required="required">';
												echo '	   Remove';
									   echo '	</button>';
									echo '</td>';

							  echo '</div>';
							  echo '</div>';
							  echo '</tr>';								
							}
						}
						
					?>
	               
	   
      </table>	
      <center><a href="institution.php" class="btn btn-primary">Save and Continue</a></center>
	  </br>
	  </form>
	  
	  
    <footer id="footer" class="midnight-blue">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    &copy; 2015 <a href="#" >NMISA</a>. All Rights Reserved.
                </div>
				
				<div class="col-sm-6">
                    <ul class="pull-right">
                        <li><a href=""><i class="fa fa-twitter"></i></a>
                        </li>
                        <li><a href="https://www.facebook.com/MDynamic-Technologies-531421617061250/?fref=ts"><i class="fa fa-facebook"></i></a>
                        </li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a>
                        </li>
                    </ul>
                </div>
				
            </div>
        </div>
    </footer><!--/#footer-->
	
		<!-- JS -->
	<script type="text/javascript" src="js/jquery.min.js"></script><!-- jQuery -->
	<script type="text/javascript" src="js/bootstrap.min.js"></script><!-- Bootstrap -->
	<script type="text/javascript" src="js/jquery.parallax.js"></script><!-- Parallax -->
	<script type="text/javascript" src="js/smoothscroll.js"></script><!-- Smooth Scroll -->
	<script type="text/javascript" src="js/masonry.pkgd.min.js"></script><!-- masonry -->
	<script type="text/javascript" src="js/jquery.fitvids.js"></script><!-- fitvids -->
	<script type="text/javascript" src="js/owl.carousel.min.js"></script><!-- Owl-Carousel -->
	<script type="text/javascript" src="js/jquery.counterup.min.js"></script><!-- CounterUp -->
	<script type="text/javascript" src="js/waypoints.min.js"></script><!-- CounterUp -->
	<script type="text/javascript" src="js/jquery.isotope.min.js"></script><!-- isotope -->
	<script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script><!-- magnific-popup -->
	<script type="text/javascript" src="js/scripts.js"></script><!-- Scripts -->

    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/wow.min.js"></script>
</body>
</html>
