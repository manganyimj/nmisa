<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Product
 *
 * @author jmanganyi
 */
class Product {
    //put your code here
    var $id;
    var $prodname;
    
    function __construct($id, $prodname) {
        $this->id = $id;
        $this->prodname = $prodname;
    }
    function getId() {
        return $this->id;
    }

    function getProdname() {
        return $this->prodname;
    }

    function setId($id) {
        $this->id = $id;
    }

    function setProdname($prodname) {
        $this->prodname = $prodname;
    }
    


}
