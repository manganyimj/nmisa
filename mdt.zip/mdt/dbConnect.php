<?php
/* 	define('HOST','localhost');
	define('USER','mdynamic_mdt');
	define('PASS','M1237894j-');
	define('DB','mdynamic_mdt');
	
	$con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');  */
	
	
	define('HOST','localhost');
	define('USER','mdt');
	define('PASS','1234');
	define('DB','mdtdbase');
	
	$con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');
?>

